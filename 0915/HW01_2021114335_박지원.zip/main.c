#include <stdio.h>

void func(void);
int main(void)
{
	printf("main.c\n");
	func();
	return 0;
}
