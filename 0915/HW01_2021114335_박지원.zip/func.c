#include <stdio.h>

void func(void)
{
	printf("func.c\n");
}
